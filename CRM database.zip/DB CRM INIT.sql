/*
SQLyog Professional v13.1.1 (64 bit)
MySQL - 8.0.37 : Database - dbcrm
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbcrm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `dbcrm`;

/*Table structure for table `token` */

DROP TABLE IF EXISTS `token`;

CREATE TABLE `token` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `is_logged_0ut` bit(1) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKe32ek7ixanakfqsdaokm4q9y2` (`user_id`),
  CONSTRAINT `FKe32ek7ixanakfqsdaokm4q9y2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `token` */

insert  into `token`(`id`,`is_logged_0ut`,`token`,`user_id`) values 
(1,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwiaWF0IjoxNzMxNDQwNDg1LCJleHAiOjE3MzE1MjY4ODV9.nKMnQLnQv2gNB8zUJaPcOPS8n1dMvms7dtYPSrHlj7mA3_4wveZ9nCiaXwalBhnl',8),
(2,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwiaWF0IjoxNzMxNDQxMTU0LCJleHAiOjE3MzE1Mjc1NTR9.TDx7rIFh4Io_7xGj-hhg94ozJRE1VHbivhmGTAUb7epVgdMDpMknFjQm3KnEYMB8',8),
(3,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNDQxNTgyLCJleHAiOjE3MzE1Mjc5ODJ9.6SJWQCH-dm7yu1t5QZU7RTEJRGG3r0guokfHfoX6iKeagtxa8nACvtAfTtognPq6',8),
(4,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsMUBnbWFpbC5jb20iLCJyb2xlIjoiQURNSU4iLCJpYXQiOjE3MzE1MjU3MjMsImV4cCI6MTczMTYxMjEyM30.ioyXsPcEqNVPcMsN9bomXozT9EjXWNPu0-CYblWHajOuRylVxvhJLqANMbz5zOuc',9),
(5,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsQGdtYWlsLmNvbSIsInJvbGUiOiJBRE1JTiIsImlhdCI6MTczMTUyOTc0NSwiZXhwIjoxNzMxNjE2MTQ1fQ.HRWti91OdTYOpI-rw6DzDzWfxfMAxEPQDdT8AwzydSqWaT78U_zLLG98mVRJIr5H',10),
(6,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVscnJyQGdtYWlsLmNvbSIsInJvbGUiOiJBR0VOVCIsImlhdCI6MTczMTUzMDE1OSwiZXhwIjoxNzMxNjE2NTU5fQ.LrC4pJKvciM_5DxluHLjD_yn7UylVT-hYg7qSI6OAiW0_fxSvVRRRHOmcK0fo8Qw',11),
(7,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhZ2VudEBnbWFpbC5jb20iLCJyb2xlIjoiU0FMRVNfRVhFQ1VUSVZFIiwiaWF0IjoxNzMxNTMwNDM2LCJleHAiOjE3MzE2MTY4MzZ9.OoY1abi0tuQwnlXQi__O-5sW6q32Pmjs88LIT34UklW1I3XC32u85CFyy2XoFjOw',12),
(8,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhdmlqaXRAZ21haWwuY29tIiwicm9sZSI6IlNBTEVTX0VYRUNVVElWRSIsImlhdCI6MTczMTUzMjUwMSwiZXhwIjoxNzMxNjE4OTAxfQ.wIAGTZFNzgaK-PO-thVXmwZysB3A7W9D72sBuGpWzN38XNnmd-fgcI2Qt-MITTTI',13),
(9,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhdmlqaXRAZ21haWwuY29tIiwicm9sZSI6IlNBTEVTX0VYRUNVVElWRSIsImlhdCI6MTczMTUzNTU5OSwiZXhwIjoxNzMxNjIxOTk5fQ.nuriKvyPFBk86cQeXGqP4uWVseGjjLnXSRja873h1Q8pmy_qzIKutD-zE8aoK3Li',13),
(10,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhdmlqaXRAZ21haWwuY29tIiwicm9sZSI6IlNBTEVTX0VYRUNVVElWRSIsImlhdCI6MTczMTUzNjM5MSwiZXhwIjoxNzMxNjIyNzkxfQ.Kn7QsTrsCucXiq19LMFD-PtfDcIyq6sSpidega376FmtWZLMdJbLd3ql_8FNsX-1',13),
(11,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhdmlqaXRAZ21haWwuY29tIiwicm9sZSI6IlNBTEVTX0VYRUNVVElWRSIsImlhdCI6MTczMTUzNjcyMCwiZXhwIjoxNzMxNjIzMTIwfQ.zx3A1Bxj5CeuFcarm4B1myzgh2nsHdJmHW7adt7G_Ag7X_bDaJoNLQQFRY1FhNR8',13),
(12,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhdmlqaXRAZ21haWwuY29tIiwicm9sZSI6IlNBTEVTX0VYRUNVVElWRSIsImlhdCI6MTczMTUzNjc1NCwiZXhwIjoxNzMxNjIzMTU0fQ.K1SfRPuEqfT4rHgpzCMFTyvwkrX2eOiAnOoQSQOPrH8lbLsvNtaDSjuCA55bJdVD',13),
(13,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM2OTY0LCJleHAiOjE3MzE2MjMzNjR9.1ptiTWUwdDh1zsZR0AwPPe1AtjnAZs0tSv61kU79UUbrUxWcdtqvyt2Ha1ixqXpN',8),
(14,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM3MjUwLCJleHAiOjE3MzE2MjM2NTB9.hmz0Qf_RbECAlmSK0KXxPGvelOQkO-3HfoKguRLHFgb5LgQtL-axNiQnVa9-n-B_',8),
(15,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM3Mzk5LCJleHAiOjE3MzE2MjM3OTl9.C-qgNFuecYhXZAOgMiX0qjGbxNTzaWulJPuW_jcYjj91uVd4BzUH6UxPDMHxlZtS',8),
(16,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM3NDI3LCJleHAiOjE3MzE2MjM4Mjd9.l2N9C6H7n0HMz7tdgaMqfRI8Ud4MK7PCcogxjlq6oDY9sq9N65nYNngPaKt6FKD0',8),
(17,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM3NDMzLCJleHAiOjE3MzE2MjM4MzN9.sBUTXBVbjCq1ENNSqX4IKvXpmSDg8dfXHfjWtrdi-lHu6HsxgYCKX37E-VmQMAKG',8),
(18,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM3NDUzLCJleHAiOjE3MzE2MjM4NTN9.ZSmw7Ys2RpbAplOrNI_bWdhEssQDBtub2qPvil-nvDtqGV7C7KzHfUTiYnXU94Fl',8),
(19,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM3NDY2LCJleHAiOjE3MzE2MjM4NjZ9.myNcDgt0TJa_tqmQOxSLe1JDNRjErlJP1TM7huQt_YYF6ch_MyFRixKY9XNPX9O_',8),
(20,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM3NTIyLCJleHAiOjE3MzE2MjM5MjJ9.vrLnCN9zjLVjEFAlHXmMvYw8cEC2X-HuEvSy1Yy4QNSwu9dPUx394ycZ-iZ1aZpy',8),
(21,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhdmlqaXRAZ21haWwuY29tIiwicm9sZSI6IlNBTEVTX0VYRUNVVElWRSIsImlhdCI6MTczMTUzNzY1MCwiZXhwIjoxNzMxNjI0MDUwfQ.X704uSh95Kf8MMCzyxKdm2MtqpuhREmtqodOYM0Zi9ZF8uU6yXuiIFFSziWXtU7m',13),
(22,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM3ODc3LCJleHAiOjE3MzE2MjQyNzd9.Zie-BsxlWP-_ga69yl_8XFT5wQgfEAGpPcWIziNjsTctKeLyAECP2wowxP5iLjIU',8),
(23,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM3ODg5LCJleHAiOjE3MzE2MjQyODl9.uImbDllh6iS0d-R4nfiLEF04TeKNanVglqkEb10rqTsjbAjGDusk430c2WlscvnG',8),
(24,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM4MDM3LCJleHAiOjE3MzE2MjQ0Mzd9.OUsYhcKAvBNN0THMUE3DrDnXOxp8RgUnTBJVytk8LWKVIP5PCyY1HOQraCM2ut-g',8),
(25,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM4MTYwLCJleHAiOjE3MzE2MjQ1NjB9.8XozDSMSK3FfaoWLpBoKqE3F6XMuKc6rzWWe24QivhhUWDDyJnDmTHEr2GocmW37',8),
(26,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxNTM4MjY3LCJleHAiOjE3MzE2MjQ2Njd9.VdxbuHvMYXbKt28XJ1OvtvXmLW3jtJErF8-W9yjJxwCIbBvuoah62-TJY5Kv63JG',8),
(27,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhdmlqaXRAZ21haWwuY29tIiwicm9sZSI6IlNBTEVTX0VYRUNVVElWRSIsImlhdCI6MTczMTUzODI5NiwiZXhwIjoxNzMxNjI0Njk2fQ.p_T6iyX1lPzx5gI3Ls4H_TEp3bq9qA6yQFA6S-V9D3BTsbRiyKyhFcrnSRcVcmSH',13),
(28,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhdmlqaXRAZ21haWwuY29tIiwicm9sZSI6IlNBTEVTX0VYRUNVVElWRSIsImlhdCI6MTczMTUzODQxNiwiZXhwIjoxNzMxNjI0ODE2fQ.-rP_ll1YxvGHRKMZVbHQpOl4ftlZ1-KfQm1aO9wP1YJzTMqQ5sTJDarUhtCFybeN',13),
(29,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhYWFhQGdtYWlsLmNvbSIsImlhdCI6MTczMTU4NTkwOCwiZXhwIjoxNzMxNjcyMzA4fQ.dMK24fMR0uhUktxdsZxvmoPwg3apPxCfj0R25PuwdhThyQLJBaVtf2cDg3VYf6AC',14),
(30,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJiYmJiQGdtYWlsLmNvbSIsImlhdCI6MTczMTU4NjAzMSwiZXhwIjoxNzMxNjcyNDMxfQ.BowrFV672bYt5Gf4YvgqGCvqKRlMP-bz_Ul0K3_hjLCHgFIOvu4eAXC73aGu5Xx_',15),
(31,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJjY2NjQGdtYWlsLmNvbSIsImlhdCI6MTczMTU4NjIxMiwiZXhwIjoxNzMxNjcyNjEyfQ.8-wdVIacxjnp7dRSxkJWiJoIQuXM07R-otSn3M6RYp9sEGgksSIeVt6eZXUSEAef',16),
(32,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJlZWVlQGdtYWlsLmNvbSIsImlhdCI6MTczMTU4NjMzOSwiZXhwIjoxNzMxNjcyNzM5fQ.DM1tmWC5W3gA4vAHDZdtVKaWQlb5-vJ37aKH4PaScIj6bB5gO081QRmdSk5W1qa7',17),
(33,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJzc3NAZ21haWwuY29tIiwiaWF0IjoxNzMxNTg2NTM4LCJleHAiOjE3MzE2NzI5Mzh9.IpGXhND3A9c7qkOWhtlHHC0sAwvrBsVWMyFGAGPRHQT9KJvVddZ89OSpz9W1IJkT',18),
(34,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxOTMxMTQ1LCJleHAiOjE3MzIwMTc1NDV9.VPl2PCaM8w6wgJgGIVzOZl-bB8UzXWd6Kr-ulWks6qi32-yeJIdKlEagoYC3OVyN',8),
(35,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxOTMxMTczLCJleHAiOjE3MzIwMTc1NzN9.P2GmIccLPH-BTB7lKh-QETgpcdYzoku0Q99AdkAEQCEcIpCM1bhou_ctqdDIZIg3',8),
(36,'','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxOTMxMTkyLCJleHAiOjE3MzIwMTc1OTJ9.1nRLHLqzGk2HrTVHKdKlEl9n2OWUbJnKMs_WY2EBYaO5tXow-hP-msA64EKiKxmG',8),
(37,'\0','eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJyYWZpcXVsaXNsYW05NzdAZ21haWwuY29tIiwicm9sZSI6IkFETUlOIiwiaWF0IjoxNzMxOTMxMzE2LCJleHAiOjE3MzIwMTc3MTZ9.E8kfOno9PPTws5xbsR2NIGED622tNQvwpMWsKCmlA0vMUBq2izMD9I8tsyvtCu-H',8);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `role` enum('ADMIN','AGENT','SALES_EXECUTIVE') DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_lock` bit(1) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `sales_amount` double NOT NULL,
  `target_amount` double NOT NULL,
  `sales_executive_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKjeylhdmxmckajs87gt1jq5joa` (`sales_executive_id`),
  CONSTRAINT `FK2v4hvx6mqgfja7tbnnkoavvkw` FOREIGN KEY (`sales_executive_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `user` */

insert  into `user`(`id`,`email`,`name`,`password`,`phone`,`role`,`status`,`active`,`address`,`is_lock`,`deadline`,`description`,`sales_amount`,`target_amount`,`sales_executive_id`) values 
(8,'rafiqulislam977@gmail.com','Razu','$2a$10$H4uHwBBWGV4l8sQ1C/Iws.A1EUbFVkseJd4Cj2chVR7dS.XFmDm6a','01775805206','ADMIN',NULL,'','Dhaka','',NULL,NULL,0,0,NULL),
(9,'rafiqul1@gmail.com','Rafiqul','$2a$10$rFFKiIP3BEKfGq/swlNb4ObaPn82IrB7M0xQ5gICxZDpEeUHyi.72','3469002','ADMIN',NULL,'','Barishal','',NULL,NULL,0,0,NULL),
(10,'rafiqul@gmail.com','Rafiqul','$2a$10$dSBVLW9exD7hPfpm5W54..Lnz3ZwGARM8JBCGoUsrTTZApZWuVVKe','375409','ADMIN',NULL,'','Barishal','',NULL,NULL,0,0,NULL),
(11,'rafiqulrrr@gmail.com','rrr','$2a$10$CqvSvXJZess2TY7YQKE5ZOc6J/WZ3pqg21XlVkUIRyTxmb/BaTqQ.','436098','AGENT',NULL,'\0','Barishal','',NULL,NULL,0,0,NULL),
(12,'agent@gmail.com','agent1','$2a$10$dsADJ4P3uO81D31vQz6cg.faR/bS9bS.nElj4RLOqwnikKUS2vqHu','3464374','SALES_EXECUTIVE',NULL,'','dhaka','',NULL,NULL,0,0,NULL),
(13,'avijit@gmail.com','avijit','$2a$10$046r9.v1uZ6Zcdl6aZOYJeQQpzft1aeEsIgOwf0vnZJiYEDn7xy3i','436857','SALES_EXECUTIVE',NULL,'','dhaka','',NULL,NULL,0,0,NULL),
(14,'aaaa@gmail.com','aaaa','$2a$10$gEg03ObtKfKLrCer7H1owePAY/ato2kP4.7aMsS7Aea.dGKJMvIj6','243687','AGENT',NULL,'\0','dhaka','',NULL,NULL,0,0,NULL),
(15,'bbbb@gmail.com','bbbb','$2a$10$b1niflXl9G9nlxHakIyx1.C2IyqS8X1QTxEmSC/0sXZtamW9Xd4xq','243687','AGENT',NULL,'\0','dhaka','',NULL,NULL,0,0,NULL),
(16,'cccc@gmail.com','cccc','$2a$10$Bey6/aItkRECSet8Opw8ium.gRQqRQ/pS.7C4J3tZwCQOl9WBBFzO','243687','AGENT',NULL,'\0','dhaka','',NULL,NULL,0,0,NULL),
(17,'eeee@gmail.com','Agent1','$2a$10$XKpToTi83mHFHtgGAmRikuGhS2wr.hF.8K2m4mHZpwJz.JVLephkm','453889','AGENT',NULL,'\0','dhaka','',NULL,NULL,0,0,NULL),
(18,'sss@gmail.com','rir','$2a$10$AGrSvNUabcNiOgQBQXJW3uSguOmbV5csDD9dmonIgpvxLEhY4QBHy','389722','AGENT',NULL,'','escrtaew','',NULL,NULL,0,0,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
